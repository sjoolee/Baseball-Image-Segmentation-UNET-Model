# baseball > 2022-11-05 3:02pm
https://universe.roboflow.com/ryan-hogan-vkxi5/baseball-zbcta

Provided by a Roboflow user
License: CC BY 4.0

